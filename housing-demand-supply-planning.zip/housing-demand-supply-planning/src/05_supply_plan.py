"""
Step 5 - Supply planning: convert the 6-month demand forecast into an inventory / new-supply plan.

Input : outputs/tables/forecast_next6.csv and forecast_meta.csv   (from step 4)
        the transaction file (only to work out each city's recent share of sales)
Output: outputs/tables/supply_plan_base.csv, scenario_summary.csv, supply_plan_by_city.csv
        outputs/charts/06_supply_plan.png

The logic is the classic inventory-planning loop used in S&OP (Sales & Operations Planning):

    safety stock         = z x forecast error (RMSE) x sqrt(lead time)      <- buffer against forecast error
    target inventory     = cover months x forecast demand  +  safety stock    <- what we want to hold at month end
    planned new supply   = max(0, target - (opening inventory - demand))      <- what must be added this month
    closing inventory    = opening inventory + planned new supply - demand    <- becomes next month's opening

ASSUMPTIONS (change them at the top of the file - they are business inputs, not facts):
    LEAD_TIME_MONTHS, SERVICE_LEVEL_Z, COVER_MONTHS and OPENING_COVER_MONTHS below.
"""
import argparse
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
CHARTS = ROOT / "outputs" / "charts"

LEAD_TIME_MONTHS = 2        # months between deciding to add supply and it being ready to sell
SERVICE_LEVEL_Z = 1.645     # z-score for a 95% service level (meet demand in 95% of months)
COVER_MONTHS = 2.0          # hold enough homes to cover 2 months of forecast demand
OPENING_COVER_MONTHS = 2.5  # ASSUMED opening stock = 2.5 x recent monthly demand (replace with your real stock)


def build_plan(demand: np.ndarray, safety_stock: float, opening_inventory: float) -> pd.DataFrame:
    """Month-by-month inventory balance for one demand path."""
    rows = []
    inventory = opening_inventory
    for month_number, d in enumerate(demand, start=1):
        target = COVER_MONTHS * d + safety_stock
        new_supply = max(0.0, target - (inventory - d))
        new_supply = float(np.ceil(new_supply))               # whole homes only
        closing = inventory + new_supply - d
        rows.append({
            "month_no": month_number,
            "forecast_demand": d,
            "safety_stock": safety_stock,
            "target_inventory": target,
            "opening_inventory": inventory,
            "planned_new_supply": new_supply,
            "closing_inventory": closing,
        })
        inventory = closing                                   # this month's closing is next month's opening
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", default=str(ROOT / "data" / "processed" / "transactions_simulated.csv"))
    parser.add_argument("--date-col", default="transaction_date")
    args = parser.parse_args()

    forecast = pd.read_csv(TABLES / "forecast_next6.csv", parse_dates=["month"])
    meta = pd.read_csv(TABLES / "forecast_meta.csv").iloc[0]
    monthly = pd.read_csv(TABLES / "monthly_demand.csv", index_col=0, parse_dates=True)["transactions"]

    safety_stock = SERVICE_LEVEL_Z * meta["backtest_rmse"] * np.sqrt(LEAD_TIME_MONTHS)
    opening = OPENING_COVER_MONTHS * monthly.iloc[-3:].mean()
    print(f"Model: {meta['best_model']} | back-test RMSE {meta['backtest_rmse']:.1f} | "
          f"safety stock {safety_stock:.0f} homes | assumed opening inventory {opening:.0f} homes")

    # Base plan plus a low-demand and a high-demand scenario (the 90% interval bounds)
    scenarios = {"Low demand (lower 90%)": forecast["lower_90"], "Base forecast": forecast["forecast"],
                 "High demand (upper 90%)": forecast["upper_90"]}
    plans = {name: build_plan(d.to_numpy(), safety_stock, opening) for name, d in scenarios.items()}

    base = plans["Base forecast"].copy()
    base.insert(0, "month", forecast["month"].dt.strftime("%b %Y"))
    base = base.drop(columns="month_no").round(0)
    base.to_csv(TABLES / "supply_plan_base.csv", index=False)

    summary = pd.DataFrame([{
        "scenario": name,
        "total_demand_6m": plan["forecast_demand"].sum(),
        "total_new_supply_6m": plan["planned_new_supply"].sum(),
        "closing_inventory_month6": plan["closing_inventory"].iloc[-1],
    } for name, plan in plans.items()]).round(0)
    summary.to_csv(TABLES / "scenario_summary.csv", index=False)

    # Split the base plan across cities using each city's share of the last 12 months of sales
    transactions = pd.read_csv(args.input, parse_dates=[args.date_col])
    if "city" in transactions.columns:
        recent = transactions[transactions[args.date_col] > transactions[args.date_col].max() - pd.DateOffset(months=12)]
        share = recent["city"].value_counts(normalize=True).sort_index()
        allocation = np.outer(plans["Base forecast"]["planned_new_supply"].to_numpy(), share.to_numpy())  # months x cities
        by_city = pd.DataFrame(np.round(allocation), columns=share.index).astype(int)
        by_city.insert(0, "month", forecast["month"].dt.strftime("%b %Y"))
        by_city.to_csv(TABLES / "supply_plan_by_city.csv", index=False)
        print("\nSUPPLY PLAN BY CITY (new homes to bring to market)\n", by_city.to_string(index=False))

    fig, ax = plt.subplots(figsize=(10, 4.5))
    labels = base["month"]
    ax.bar(labels, base["planned_new_supply"], color="#2e8b8b", label="Planned new supply")
    ax.plot(labels, base["forecast_demand"], color="#c0392b", marker="o", label="Forecast demand")
    ax.plot(labels, base["closing_inventory"], color="black", marker="s", ls="--", label="Closing inventory")
    ax.set_ylabel("Homes")
    demo = "\n(SIMULATED DEMO DATA)" if "simulated" in Path(args.input).name else ""
    ax.set_title("6-month supply plan (base forecast)" + demo)
    ax.legend(frameon=False)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(CHARTS / "06_supply_plan.png", dpi=150)
    plt.close()

    print("\nBASE PLAN\n", base.to_string(index=False))
    print("\nSCENARIOS\n", summary.to_string(index=False))


if __name__ == "__main__":
    main()
