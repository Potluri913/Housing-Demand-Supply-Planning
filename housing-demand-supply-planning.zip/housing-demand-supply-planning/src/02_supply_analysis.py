"""
Step 2 - Supply-side profiling of the six city housing markets (REAL data).

Input : data/processed/listings_clean.csv
Output: outputs/tables/*.csv  and  outputs/charts/*.png

What "supply" means here: the homes currently listed for sale. Before planning how much new
supply is needed (step 5) you first need to know what the existing inventory looks like:
how big it is, what it costs, which unit types dominate and how concentrated it is by locality.

NOTE: the listing files have no dates, so they describe a snapshot of supply.
They cannot be used for time-series demand forecasting (that is why steps 3-4 exist).
"""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
CHARTS = ROOT / "outputs" / "charts"
TABLES.mkdir(parents=True, exist_ok=True)
CHARTS.mkdir(parents=True, exist_ok=True)

CITY_ORDER = ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata"]


def city_summary(listings: pd.DataFrame) -> pd.DataFrame:
    """Size and price level of the listed inventory in each city."""
    out = listings.groupby("city").agg(
        listings=("price", "size"),
        median_price_lakh=("price", lambda s: s.median() / 1e5),
        median_area_sqft=("area_sqft", "median"),
        median_price_per_sqft=("price_per_sqft", "median"),
        resale_share_pct=("resale", lambda s: s.mean() * 100),
    )
    return out.reindex(CITY_ORDER).round(1)


def bhk_mix(listings: pd.DataFrame) -> pd.DataFrame:
    """Share (%) of each unit type (1-5 BHK) in a city's inventory."""
    return (pd.crosstab(listings["city"], listings["bhk"], normalize="index") * 100).reindex(CITY_ORDER).round(1)


def price_band_mix(listings: pd.DataFrame) -> pd.DataFrame:
    """Share (%) of inventory in each price band - shows which budget segments are thin."""
    return (pd.crosstab(listings["city"], listings["price_band"], normalize="index") * 100).reindex(CITY_ORDER).round(1)


def locality_concentration(listings: pd.DataFrame) -> pd.DataFrame:
    """
    How concentrated is supply across localities?
      top10_share_pct : % of all listings that sit in the 10 biggest localities
      hhi             : Herfindahl-Hirschman Index = sum(share^2) x 10,000
                        (low = spread over many localities, high = concentrated)
    """
    rows = []
    for city in CITY_ORDER:
        shares = listings.loc[listings["city"] == city, "locality"].value_counts(normalize=True).to_numpy()
        rows.append({
            "city": city,
            "localities": len(shares),
            "top10_share_pct": np.sort(shares)[::-1][:10].sum() * 100,
            "hhi": (shares ** 2).sum() * 10_000,
        })
    return pd.DataFrame(rows).set_index("city").round(1)


def plot_bhk_mix(mix: pd.DataFrame) -> None:
    ax = mix.plot(kind="barh", stacked=True, figsize=(9, 4.5), colormap="viridis", width=0.75)
    ax.set_xlabel("Share of listed inventory (%)")
    ax.set_ylabel("")
    ax.set_title("Inventory mix by unit type (BHK)")
    ax.invert_yaxis()
    ax.legend(title="", ncol=5, loc="upper center", bbox_to_anchor=(0.5, -0.15), frameon=False)
    plt.tight_layout()
    plt.savefig(CHARTS / "01_inventory_mix_by_bhk.png", dpi=150)
    plt.close()


def plot_price_per_sqft(listings: pd.DataFrame) -> None:
    data = [listings.loc[listings["city"] == c, "price_per_sqft"] for c in CITY_ORDER]
    fig, ax = plt.subplots(figsize=(9, 4.5))
    ax.boxplot(data, showfliers=False)
    ax.set_xticklabels(CITY_ORDER)
    ax.set_ylabel("Price per sq ft (Rs)")
    ax.set_title("Price per sq ft by city (median and interquartile range)")
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(CHARTS / "02_price_per_sqft_by_city.png", dpi=150)
    plt.close()


def main() -> None:
    listings = pd.read_csv(ROOT / "data" / "processed" / "listings_clean.csv")

    summary = city_summary(listings)
    mix = bhk_mix(listings)
    bands = price_band_mix(listings)
    concentration = locality_concentration(listings)

    summary.to_csv(TABLES / "supply_by_city.csv")
    mix.to_csv(TABLES / "supply_mix_by_bhk.csv")
    bands.to_csv(TABLES / "supply_mix_by_price_band.csv")
    concentration.to_csv(TABLES / "locality_concentration.csv")

    plot_bhk_mix(mix)
    plot_price_per_sqft(listings)

    print("SUPPLY BY CITY\n", summary, "\n")
    print("BHK MIX (%)\n", mix, "\n")
    print("PRICE BAND MIX (%)\n", bands, "\n")
    print("LOCALITY CONCENTRATION\n", concentration)


if __name__ == "__main__":
    main()
