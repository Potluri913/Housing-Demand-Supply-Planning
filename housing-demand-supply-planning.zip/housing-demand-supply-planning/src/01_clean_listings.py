"""
Step 1 - Load and clean the six city listing files into ONE tidy dataset.

Input : data/raw/<City>.csv  (Mumbai, Delhi, Bangalore, Hyderabad, Chennai, Kolkata)
Output: data/processed/listings_clean.csv
        outputs/tables/cleaning_log.csv   (how many rows each cleaning step removed)

Data issues found while profiling the raw files (and how this script handles them):
  1. Hyderabad.csv stores prices as text like "? 69,68,000.00" (Indian number format,
     rupee sign corrupted to "?")  -> strip everything except digits and ".", convert to float.
  2. Hyderabad.csv has a junk last row (Area = "avg") -> becomes NaN and is dropped.
  3. In the amenity columns the value 9 looks like a "not available" placeholder (it appears only next
     to 0/1 and covers from 3% of cells in Hyderabad to 99% in Kolkata) -> replaced with NaN,
     NOT treated as "has amenity". Because amenity data is so sparse it is not used in later steps.
  4. Exact duplicate rows exist -> dropped.
  5. Extreme price-per-sqft values (data-entry errors) -> trimmed to the 1st-99th percentile per city.
  6. Bedroom counts above 5 are rare/suspicious -> rows kept only for 1-5 bedrooms.
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
PROCESSED = ROOT / "data" / "processed"
TABLES = ROOT / "outputs" / "tables"
PROCESSED.mkdir(parents=True, exist_ok=True)
TABLES.mkdir(parents=True, exist_ok=True)

CITIES = ["Mumbai", "Delhi", "Bangalore", "Hyderabad", "Chennai", "Kolkata"]
RENAME = {
    "Price": "price",
    "Area": "area_sqft",
    "Location": "locality",
    "No. of Bedrooms": "bedrooms",
    "Resale": "resale",
}


def load_city(city: str) -> pd.DataFrame:
    """Read one city file and standardise its column names and number formats."""
    df = pd.read_csv(RAW / f"{city}.csv")

    # Hyderabad has an extra pre-computed price-per-sqft text column; we recompute it ourselves.
    df = df.drop(columns=[c for c in df.columns if c.startswith("Price per Sqft")], errors="ignore")
    df = df.rename(columns=RENAME)

    # Convert text columns such as "? 69,68,000.00" into numbers.
    for col in ["price", "area_sqft"]:
        if not pd.api.types.is_numeric_dtype(df[col]):
            cleaned = df[col].astype(str).str.replace(r"[^0-9.]", "", regex=True)
            df[col] = pd.to_numeric(cleaned, errors="coerce")

    # Amenity columns are everything after "resale". The value 9 means "unknown".
    amenity_cols = list(df.columns[df.columns.get_loc("resale") + 1:])
    df[amenity_cols] = df[amenity_cols].replace(9, np.nan)

    df.insert(0, "city", city)
    return df


def clean_city(df: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    """Apply the row-level cleaning rules and record how many rows each step removed."""
    log = {"city": df["city"].iloc[0], "rows_raw": len(df)}

    df = df.dropna(subset=["price", "area_sqft", "locality", "bedrooms"])
    log["after_missing_removed"] = len(df)

    df = df.drop_duplicates()
    log["after_duplicates_removed"] = len(df)

    df = df.assign(bedrooms=df["bedrooms"].astype(int))
    df = df[df["bedrooms"].between(1, 5)]
    log["after_bedroom_filter"] = len(df)

    df = df.assign(
        locality=df["locality"].str.strip(),
        price_per_sqft=df["price"] / df["area_sqft"],
    )

    # Trim the extreme 1% at each end of price-per-sqft (data-entry errors) - per city,
    # because a Mumbai price level is not comparable with a Kolkata one.
    low, high = np.percentile(df["price_per_sqft"], [1, 99])
    df = df[df["price_per_sqft"].between(low, high)]
    log["after_outlier_trim"] = len(df)
    return df, log


def main() -> None:
    cleaned_frames, logs = [], []
    for city in CITIES:
        df, log = clean_city(load_city(city))
        cleaned_frames.append(df)
        logs.append(log)

    listings = pd.concat(cleaned_frames, ignore_index=True)
    listings["bhk"] = listings["bedrooms"].astype(str) + " BHK"
    listings["price_band"] = pd.cut(
        listings["price"],
        bins=[0, 5e6, 1e7, 2e7, np.inf],
        labels=["Under 50L", "50L-1Cr", "1Cr-2Cr", "Above 2Cr"],
    )

    listings.to_csv(PROCESSED / "listings_clean.csv", index=False)
    pd.DataFrame(logs).to_csv(TABLES / "cleaning_log.csv", index=False)

    print(pd.DataFrame(logs).to_string(index=False))
    print(f"\nSaved {len(listings):,} clean listings -> data/processed/listings_clean.csv")


if __name__ == "__main__":
    main()
