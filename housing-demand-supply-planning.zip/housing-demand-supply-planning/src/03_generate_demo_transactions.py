"""
Step 3 - Build a SIMULATED transaction history so the forecasting pipeline can be demonstrated.

*** IMPORTANT - READ THIS ***
The uploaded listing files contain NO dates, so they cannot show how demand changes over time.
To demonstrate forecasting anyway, this script simulates 72 months (Jan 2019 - Dec 2024) of
home-sale transactions:

  REAL      : the property attributes (city, locality, BHK, area, price) are sampled from the
              cleaned listings in data/processed/listings_clean.csv
  SIMULATED : the transaction DATES and monthly VOLUMES (a trend + yearly seasonality + random noise)

Every result produced from this file (MAPE, forecast, supply plan) is therefore a demonstration of
the METHOD, not a finding about the real housing market.

To use real data, skip this step and pass your own file to step 4:
    python src/04_demand_forecast.py --input path/to/transactions.csv --date-col transaction_date
"""
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
PROCESSED = ROOT / "data" / "processed"

SEED = 42                # fixed seed -> the same "random" data every run (reproducible)
N_MONTHS = 72
START = "2019-01-01"
BASE_DEMAND = 60         # average transactions per month at the start
TREND_PER_MONTH = 0.005  # +0.5% per month underlying growth

# Relative seasonal strength per calendar month (Jan..Dec): financial year-end (Mar) and festive
# season (Oct-Nov) are stronger, monsoon/summer months are weaker. Rescaled so the average is 1.0.
SEASONAL = np.array([0.92, 0.90, 1.12, 0.88, 0.90, 0.93, 0.97, 1.02, 1.05, 1.15, 1.10, 1.06])
SEASONAL = SEASONAL / SEASONAL.mean()


def main() -> None:
    rng = np.random.default_rng(SEED)
    listings = pd.read_csv(PROCESSED / "listings_clean.csv")
    listings = listings[["city", "locality", "bedrooms", "area_sqft", "price"]]

    months = pd.date_range(START, periods=N_MONTHS, freq="MS")           # first day of each month
    trend = 1 + TREND_PER_MONTH * np.arange(N_MONTHS)                    # 1.000, 1.005, 1.010, ...
    expected = BASE_DEMAND * trend * SEASONAL[months.month - 1]          # expected sales per month
    actual_counts = rng.poisson(expected)                                # random count around expectation

    frames = []
    for month_start, n_sales in zip(months, actual_counts):
        sampled = listings.sample(n=n_sales, replace=True, random_state=int(rng.integers(1_000_000)))
        days = rng.integers(0, month_start.days_in_month, size=n_sales)  # random day inside the month
        sampled = sampled.assign(transaction_date=month_start + pd.to_timedelta(days, unit="D"))
        frames.append(sampled)

    transactions = pd.concat(frames, ignore_index=True)
    transactions = transactions.sort_values("transaction_date").reset_index(drop=True)
    transactions["is_simulated"] = True
    transactions = transactions[["transaction_date", "city", "locality", "bedrooms", "area_sqft", "price", "is_simulated"]]

    transactions.to_csv(PROCESSED / "transactions_simulated.csv", index=False)
    print(f"Simulated {len(transactions):,} transactions over {N_MONTHS} months")
    first, last = transactions["transaction_date"].min().date(), transactions["transaction_date"].max().date()
    print(f"-> data/processed/transactions_simulated.csv  (dates {first} to {last})")

if __name__ == "__main__":
    main()
