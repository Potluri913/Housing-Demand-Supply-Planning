"""
Step 4 - Demand forecasting: turn transaction records into a monthly demand series, compare three
models with a rolling back-test, and forecast the next 6 months.

Input : a table with ONE ROW PER TRANSACTION and a date column
        default = data/processed/transactions_simulated.csv (SIMULATED - see step 3)
        your own data:  python src/04_demand_forecast.py --input my_transactions.csv --date-col sale_date
Output: outputs/tables/monthly_demand.csv, seasonal_index.csv, model_comparison.csv,
        forecast_next6.csv, forecast_meta.csv   and   outputs/charts/03..05_*.png

Models compared (all forecast 6 months ahead):
  1. Seasonal naive      - "same as this month last year"  (a baseline any real model must beat)
  2. Holt-Winters        - level + trend + seasonality, written from scratch with NumPy
  3. SARIMA (1,1,1)(0,1,1,12) - seasonal ARIMA from statsmodels

Validation: expanding-window back-test. Train on the first n-18 months, forecast the next 6, compare
with what really happened; repeat with n-12 and n-6 months of training. That gives 18 forecast errors.
"""
import argparse
import warnings
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
TABLES = ROOT / "outputs" / "tables"
CHARTS = ROOT / "outputs" / "charts"
TABLES.mkdir(parents=True, exist_ok=True)
CHARTS.mkdir(parents=True, exist_ok=True)

M = 12          # season length: 12 months
HORIZON = 6     # forecast 6 months ahead
Z_90 = 1.645    # z-score for a 90% interval

# Holt-Winters smoothing-parameter grid (each between 0 and 1)
ALPHAS = [0.1, 0.3, 0.5, 0.7, 0.9]    # level:    higher = react faster to recent months
BETAS = [0.01, 0.05, 0.1, 0.2]        # trend:    higher = trend changes faster
GAMMAS = [0.1, 0.3, 0.5, 0.7]         # seasonal: higher = seasonal pattern adapts faster


# ----------------------------------------------------------------------------- data preparation
def load_monthly_demand(path: Path, date_col: str) -> pd.Series:
    """Count transactions per month: raw records -> a monthly time series."""
    df = pd.read_csv(path, parse_dates=[date_col])
    monthly = df.set_index(date_col).resample("MS").size()   # "MS" = month start; empty months become 0
    monthly.name = "transactions"
    return monthly


# ----------------------------------------------------------------------------- forecasting models
def seasonal_naive(train: np.ndarray, h: int) -> np.ndarray:
    """Forecast each future month with the value from the same month one year earlier."""
    n = len(train)
    return np.array([train[n - M + (k % M)] for k in range(h)])


def holt_winters_filter(y, alpha, beta, gamma):
    """
    Run additive Holt-Winters through the series y, one month at a time.
    Returns the one-step-ahead fitted values and the final level, trend and seasonal components.
        forecast(t) = level + trend + season[t]
    After seeing the actual value y[t], each component is updated:
        level  <- alpha * (y - season)          + (1 - alpha) * (old level + trend)
        trend  <- beta  * (new level - old level) + (1 - beta) * old trend
        season <- gamma * (y - new level)       + (1 - gamma) * old season
    """
    level = y[:M].mean()                                   # starting level = average of year 1
    trend = (y[M:2 * M].mean() - y[:M].mean()) / M         # starting trend = year-2 vs year-1 change per month
    season = y[:M] - level                                 # starting seasonal effect of each calendar month
    fitted = np.empty(len(y))
    for t in range(len(y)):
        s = season[t % M]
        fitted[t] = level + trend + s
        previous_level = level
        level = alpha * (y[t] - s) + (1 - alpha) * (level + trend)
        trend = beta * (level - previous_level) + (1 - beta) * trend
        season[t % M] = gamma * (y[t] - level) + (1 - gamma) * s
    return fitted, level, trend, season


def holt_winters(train: np.ndarray, h: int) -> np.ndarray:
    """Pick alpha/beta/gamma that minimise squared one-step error on the training data, then forecast."""
    best_sse, best_params = np.inf, None
    for alpha in ALPHAS:
        for beta in BETAS:
            for gamma in GAMMAS:
                fitted, *_ = holt_winters_filter(train, alpha, beta, gamma)
                sse = np.sum((train[M:] - fitted[M:]) ** 2)   # skip year 1: it was used to initialise
                if sse < best_sse:
                    best_sse, best_params = sse, (alpha, beta, gamma)
    _, level, trend, season = holt_winters_filter(train, *best_params)
    n = len(train)
    return np.array([level + (k + 1) * trend + season[(n + k) % M] for k in range(h)])


def sarima(train: np.ndarray, h: int) -> np.ndarray:
    """Seasonal ARIMA(1,1,1)(0,1,1,12): differencing removes trend and seasonality, then AR/MA terms model the rest."""
    from statsmodels.tsa.statespace.sarimax import SARIMAX
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        model = SARIMAX(train, order=(1, 1, 1), seasonal_order=(0, 1, 1, M),
                        enforce_stationarity=False, enforce_invertibility=False)
        return np.asarray(model.fit(disp=False).forecast(h))


# ----------------------------------------------------------------------------- evaluation
def error_metrics(actual: np.ndarray, forecast: np.ndarray) -> dict:
    error = actual - forecast
    return {
        "MAPE_pct": np.mean(np.abs(error) / actual) * 100,   # average % error
        "MAE": np.mean(np.abs(error)),                       # average error in transactions
        "RMSE": np.sqrt(np.mean(error ** 2)),                # like MAE but punishes big misses
    }


def backtest(model, y: np.ndarray):
    """Expanding-window back-test. Returns actuals and forecasts, 6 months per fold, folds joined."""
    n = len(y)
    actuals, forecasts = [], []
    for origin in (n - 3 * HORIZON, n - 2 * HORIZON, n - HORIZON):
        train, test = y[:origin], y[origin:origin + HORIZON]
        forecasts.append(model(train, HORIZON))
        actuals.append(test)
    return np.concatenate(actuals), np.concatenate(forecasts)


# ----------------------------------------------------------------------------- charts
def plot_seasonality(monthly: pd.Series, seasonal_index: pd.Series, tag: str = "") -> None:
    fig, axes = plt.subplots(1, 2, figsize=(11, 4))
    axes[0].plot(monthly.index, monthly.values, color="#1f4e79")
    axes[0].set_title("Monthly transactions" + tag)
    axes[0].grid(alpha=0.3)
    axes[1].bar(seasonal_index.index, seasonal_index.values, color="#2e8b8b")
    axes[1].axhline(1, color="black", lw=0.8)
    axes[1].set_xticks(range(1, 13))
    axes[1].set_title("Seasonal index (1.0 = average month)")
    axes[1].grid(axis="y", alpha=0.3)
    plt.tight_layout()
    plt.savefig(CHARTS / "03_demand_trend_and_seasonality.png", dpi=150)
    plt.close()


def plot_backtest(monthly, last_fold_forecasts: dict, tag: str = "") -> None:
    fig, ax = plt.subplots(figsize=(10, 4.5))
    history = monthly.iloc[-24:]
    ax.plot(history.index, history.values, color="black", lw=2, label="Actual")
    test_index = monthly.index[-HORIZON:]
    for name, values in last_fold_forecasts.items():
        ax.plot(test_index, values, marker="o", label=name)
    ax.axvline(monthly.index[-HORIZON], color="grey", ls="--")
    ax.set_title("Hold-out check: last 6 months - actual vs model forecasts" + tag)
    ax.set_ylabel("Transactions per month")
    ax.legend(frameon=False)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(CHARTS / "04_backtest_last_6_months.png", dpi=150)
    plt.close()


def plot_forecast(monthly, forecast_table: pd.DataFrame, model_name: str, tag: str = "") -> None:
    fig, ax = plt.subplots(figsize=(10, 4.5))
    history = monthly.iloc[-36:]
    ax.plot(history.index, history.values, color="black", lw=2, label="Actual")
    ax.plot(forecast_table["month"], forecast_table["forecast"], color="#c0392b", marker="o", label=f"Forecast ({model_name})")
    ax.fill_between(forecast_table["month"], forecast_table["lower_90"], forecast_table["upper_90"],
                    color="#c0392b", alpha=0.2, label="90% interval")
    ax.set_title("Demand forecast - next 6 months" + tag)
    ax.set_ylabel("Transactions per month")
    ax.legend(frameon=False)
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(CHARTS / "05_demand_forecast_next_6_months.png", dpi=150)
    plt.close()


# ----------------------------------------------------------------------------- main
def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--input", default=str(ROOT / "data" / "processed" / "transactions_simulated.csv"))
    parser.add_argument("--date-col", default="transaction_date")
    args = parser.parse_args()

    monthly = load_monthly_demand(Path(args.input), args.date_col)
    y = monthly.to_numpy(dtype=float)
    if len(y) < 36:
        raise SystemExit(f"Need at least 36 months of history, found {len(y)}.")
    print(f"{int(y.sum()):,} transactions -> {len(y)} months ({monthly.index[0]:%b %Y} to {monthly.index[-1]:%b %Y})")

    # Trend and seasonality: average each calendar month, divide by the overall average
    seasonal_index = (monthly.groupby(monthly.index.month).mean() / monthly.mean()).round(3)
    seasonal_index.index.name = "calendar_month"
    monthly.to_csv(TABLES / "monthly_demand.csv")
    seasonal_index.rename("seasonal_index").to_csv(TABLES / "seasonal_index.csv")
    tag = "\n(SIMULATED DEMO DATA)" if "simulated" in Path(args.input).name else ""
    plot_seasonality(monthly, seasonal_index, tag)

    # Compare models with the back-test
    models = {"Seasonal naive": seasonal_naive, "Holt-Winters (additive)": holt_winters}
    try:
        import statsmodels  # noqa: F401
        models["SARIMA (1,1,1)(0,1,1,12)"] = sarima
    except ImportError:
        print("statsmodels not installed - skipping SARIMA (pip install statsmodels)")

    rows, last_fold = [], {}
    for name, model in models.items():
        actual, forecast = backtest(model, y)
        rows.append({"model": name, **error_metrics(actual, forecast)})
        last_fold[name] = forecast[-HORIZON:]
    comparison = pd.DataFrame(rows).sort_values("MAPE_pct").round(2).reset_index(drop=True)
    comparison.to_csv(TABLES / "model_comparison.csv", index=False)
    print("\nBACK-TEST RESULTS (18 forecast months)\n", comparison.to_string(index=False))
    plot_backtest(monthly, last_fold, tag)

    # Refit the best model on ALL data and forecast the next 6 months
    best_name = comparison.loc[0, "model"]
    best_rmse = comparison.loc[0, "RMSE"]
    point = models[best_name](y, HORIZON)
    future_months = pd.date_range(monthly.index[-1] + pd.offsets.MonthBegin(1), periods=HORIZON, freq="MS")
    forecast_table = pd.DataFrame({
        "month": future_months,
        "forecast": np.round(point, 1),
        "lower_90": np.round(np.maximum(point - Z_90 * best_rmse, 0), 1),   # interval width comes from back-test error
        "upper_90": np.round(point + Z_90 * best_rmse, 1),
    })
    forecast_table.to_csv(TABLES / "forecast_next6.csv", index=False)
    pd.DataFrame([{"best_model": best_name, "backtest_rmse": best_rmse}]).to_csv(TABLES / "forecast_meta.csv", index=False)
    plot_forecast(monthly, forecast_table, best_name, tag)

    print(f"\nBest model: {best_name}\n", forecast_table.to_string(index=False))


if __name__ == "__main__":
    main()
