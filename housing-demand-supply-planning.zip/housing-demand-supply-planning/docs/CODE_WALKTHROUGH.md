# Code walkthrough

A guide to explaining every script: what it does, the key lines, and questions you should be able to answer.

## 30-second summary

"I cleaned real listing data for six cities, profiled the supply, then built a demand-forecasting and supply-planning pipeline. The listing data has no dates, so I simulated the transaction dates and volumes to demonstrate the method: I aggregated transactions to a monthly series, compared a seasonal-naive baseline, a Holt-Winters model I wrote in NumPy and SARIMA with a rolling back-test, picked the best, and used its forecast and error to plan safety stock and new supply under three demand scenarios."

Always say clearly that the transaction dates and volumes are simulated. That is stated in the README and on the charts, and being upfront about it is a strength.

---

## Step 1 - `01_clean_listings.py` (pandas)

**Goal:** six inconsistent files -> one clean table.

| Code | What to say |
|---|---|
| `pd.read_csv(...)` in `load_city` | Reads one city file into a DataFrame. |
| `df.rename(columns=RENAME)` | Gives every city the same column names so the files can be stacked. |
| `str.replace(r"[^0-9.]", "", regex=True)` then `pd.to_numeric(..., errors="coerce")` | Hyderabad prices are text like `"? 69,68,000.00"`. The regex removes everything except digits and the decimal point; `coerce` turns anything unreadable into NaN. |
| `df[amenity_cols].replace(9, np.nan)` | 9 appears to be a "not available" code, so it becomes missing instead of being counted as "has amenity". |
| `dropna(subset=[...])` | Drops rows missing a key field (price, area, locality, bedrooms). |
| `drop_duplicates()` | Removes exact duplicate rows. |
| `np.percentile(price_per_sqft, [1, 99])` and `.between(low, high)` | Trims the extreme 1% at each end, per city, because price levels differ by city. |
| `pd.cut(price, bins, labels)` | Buckets prices into bands (under 50L, 50L-1Cr, 1-2Cr, above 2Cr). |
| `pd.concat(frames)` | Stacks the six cleaned cities. |

**Be ready for:**
- *Why trim 1-99%? Why per city?* Data-entry errors distort medians and charts; Mumbai and Kolkata are not comparable, so a single national cut-off would remove the wrong rows.
- *Isn't dropping duplicates risky?* Yes - identical units in one project could be genuine. It is listed as a limitation.
- *How did you validate the Hyderabad parsing?* Compared it with the clean Excel version of the same file: zero difference across 2,518 rows.

---

## Step 2 - `02_supply_analysis.py` (pandas + NumPy)

**Goal:** understand today's supply before planning future supply.

| Code | What to say |
|---|---|
| `groupby("city").agg(...)` | One row per city: count, median price, median area, median price per sqft, resale share. Medians are used because prices are skewed. |
| `pd.crosstab(city, bhk, normalize="index")` | Share of each unit type within each city (each row sums to 100%). |
| `value_counts(normalize=True)` | Each locality's share of a city's listings. |
| `np.sort(shares)[::-1][:10].sum()` | Sorts shares high to low, takes the top 10, sums them: the top-10 locality share. |
| `(shares ** 2).sum() * 10_000` | Herfindahl-Hirschman Index. Low = spread across many localities; high = concentrated. |

**Be ready for:** *Why is this "supply planning"?* You cannot plan new supply without knowing the existing inventory mix and where it is concentrated. *Can you forecast demand from this data?* No - there are no dates, which is why the forecasting part uses a time series.

---

## Step 3 - `03_generate_demo_transactions.py` (NumPy)

**Goal:** create dated transactions so the forecasting method can be shown.

| Code | What to say |
|---|---|
| `np.random.default_rng(42)` | Random-number generator with a fixed seed, so results are reproducible. |
| `expected = BASE_DEMAND * trend * SEASONAL[month - 1]` | Expected sales in a month = starting level x growth trend x that calendar month's seasonal factor. |
| `rng.poisson(expected)` | Actual sales are a random count around the expectation. Poisson is the standard distribution for event counts. |
| `listings.sample(n, replace=True)` | Assigns real property attributes (city, locality, BHK, area, price) to each simulated sale. |

**Be ready for:** *Why simulate?* The real files have no dates. *What is real vs simulated?* Attributes are real; dates and volumes are simulated. *Do the results mean anything about the market?* No, they demonstrate the method; with real dated transactions the same code applies.

---

## Step 4 - `04_demand_forecast.py` (pandas + NumPy + statsmodels)

**Goal:** monthly demand series -> best model -> 6-month forecast.

| Code | What to say |
|---|---|
| `df.set_index(date).resample("MS").size()` | Groups transactions by month start and counts them: records -> monthly time series. Empty months become 0. |
| `groupby(index.month).mean() / mean()` | Seasonal index: average of each calendar month divided by the overall average. 1.2 = 20% above a normal month. |
| `seasonal_naive` | Forecast = same month last year. A baseline every real model must beat. |
| `holt_winters_filter` | Three components updated each month: **level** (base demand), **trend** (growth per month) and **season** (calendar effect). The forecast is level + trend + season. |
| `alpha`, `beta`, `gamma` | How quickly level, trend and seasonality adapt (0-1). Higher = react faster to recent data. |
| Grid search in `holt_winters` | Tries every combination and keeps the one with the smallest squared one-step error on training data. |
| `SARIMAX(order=(1,1,1), seasonal_order=(0,1,1,12))` | Seasonal ARIMA. The `1`s in d and D mean differencing once to remove trend and yearly seasonality; the AR/MA terms model what is left. Called from statsmodels. |
| `backtest(...)` | Expanding window: train on n-18 months, forecast 6, compare; then n-12; then n-6. That gives 18 forecast errors per model. |
| `error_metrics` | MAPE = average % error; MAE = average miss in transactions; RMSE = like MAE but punishes large misses. |
| `point +/- 1.645 * best_rmse` | 90% interval built from real back-test error. |

**Be ready for:**
- *Why not just split train/test once?* One 6-month test can be lucky or unlucky; three windows are more reliable.
- *Why did SARIMA lose?* Most likely because with only 54-66 training months and a seasonal difference it has few effective observations, while Holt-Winters suits this clean level + trend + season pattern. It is a result on this data, not a general rule, and you should say you did not tune SARIMA further.
- *Is 11% MAPE good?* Monthly sales are random counts of about 70, so even a perfect model has roughly 9-10% MAPE from noise alone. 11% is close to that floor.
- *What is MAPE's weakness?* It blows up when actual values are near zero and treats over- and under-forecasts differently.

---

## Step 5 - `05_supply_plan.py` (NumPy + pandas)

**Goal:** turn the forecast into how many homes to bring to market.

| Code | What to say |
|---|---|
| `SERVICE_LEVEL_Z * rmse * sqrt(LEAD_TIME)` | Safety stock: a buffer for forecast error. Error grows with the square root of the lead time; 1.645 is the z-score for a 95% service level. |
| `target = COVER_MONTHS * demand + safety_stock` | Inventory we want to hold at the end of the month. |
| `new_supply = max(0, target - (inventory - demand))` | What is left after this month's sales, and how much must be added to reach the target (never negative). |
| `np.ceil(...)` | Whole homes only. |
| `inventory = closing` | This month's closing stock is next month's opening stock: the inventory-balance loop. |
| Low / base / high scenarios | Same plan using the lower bound, forecast and upper bound of the 90% interval. Shows how much supply risk the forecast error creates. |
| `np.outer(plan, share)` | Splits each month's plan across cities using each city's share of the last 12 months of sales (matrix of months x cities). |

**Be ready for:**
- *What are the assumptions?* Lead time, service level, cover months and opening stock are business inputs at the top of the file; opening stock is assumed and would come from real stock data.
- *Why is April's new supply so low?* The forecast is seasonally weak in April and there is enough opening stock, so little needs to be added.
- *How would you improve it?* Use real stock levels, cost of holding vs cost of shortage to choose the service level, and forecast by city or unit type.

---

## Concepts to revise before an interview

Trend vs seasonality; exponential smoothing; ARIMA differencing; MAPE / MAE / RMSE; back-testing vs a single split; safety stock and service level; inventory balance; why medians instead of means for prices.
